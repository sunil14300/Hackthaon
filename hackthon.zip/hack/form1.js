const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    if (req.method === 'POST' && req.url === '/submit') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            const formData = parseFormData(body);
            console.log("Event Name:", formData.eventName);
            console.log("Organizer Name:", formData.organizerName);
            console.log("Guest Name:", formData.guestName);
            console.log("Venue Name:", formData.venueName);
            console.log("Description:", formData.description);
            res.writeHead(200, {'Content-Type': 'text/plain'});
            res.end('Form data received successfully.');
        });
    } else {
        res.writeHead(404, {'Content-Type': 'text/plain'});
        res.end('Not Found');
    }
});

function parseFormData(body) {
    const formData = {};
    body.split('&').forEach(keyValue => {
        const [key, value] = keyValue.split('=').map(decodeURIComponent);
        formData[key] = value;
    });
    return formData;
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
